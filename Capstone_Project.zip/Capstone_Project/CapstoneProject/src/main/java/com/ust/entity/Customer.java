package com.ust.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long account_No;
	private String name;
	public long getAccount_No() {
		return account_No;
	}
	public void setAccount_No(long account_No) {
		this.account_No = account_No;
	}
	private String userName;
	private String password;
	private String dob;
	private String gender;
	private String mobile_no;
	private double account_Balance;
	private String branch_id;
	
	public long getAccount_no() {
		return account_No;
	}
	public String getBranch_id() {
		return branch_id;
	}
	public void setBranch_id(String branch_id) {
		this.branch_id = branch_id;
	}
	public void setAccount_no(long account_no) {
		account_no = account_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public double getAccount_Balance() {
		return account_Balance;
	}
	public void setAccount_Balance(double account_Balance) {
		this.account_Balance = account_Balance;
	}
	@Override
	public String toString() {
		return "Customer [account_No=" + account_No + ", name=" + name + ", userName=" + userName + ", password="
				+ password + ", dob=" + dob + ", gender=" + gender + ", mobile_no=" + mobile_no + ", account_Balance="
				+ account_Balance + ", branch_id=" + branch_id + "]";
	}
	
	
	
	
	
	

}
