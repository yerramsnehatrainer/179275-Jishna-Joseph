package com.ust.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Bank {
	
	@Id
	private int branch_Id;
	private String branch_name;
	private String location;
	private String ifsc_code;
	
	public int getBranch_Id() {
		return branch_Id;
	}
	public void setBranch_Id(int branch_Id) {
		this.branch_Id = branch_Id;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getIfsc_code() {
		return ifsc_code;
	}
	public void setIfsc_code(String ifsc_code) {
		this.ifsc_code = ifsc_code;
	}
	@Override
	public String toString() {
		return "Bank [branch_Id=" + branch_Id + ", branch_name=" + branch_name + ", location=" + location
				+ ", ifsc_code=" + ifsc_code + "]";
	}
	

}
