create database capstonebankingapp;

use capstonebankingapp;

select * from customer;

select * from bank;

select * from fund_transfer;