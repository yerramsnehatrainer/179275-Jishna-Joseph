
package com.ust.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.entity.Customer;
import com.ust.model.Response;
import com.ust.repositories.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepo repo;
	List<Customer> list2 = new ArrayList<>();

	public Response showList() {
		// TODO Auto-generated method stub

		list2 = repo.findAll();
		Response res = new Response();
		if (!list2.isEmpty()) {
			res.setStatus("Below List of customers Avilable In DB");
			res.setCustomer(list2);
		} else {
			res.setStatus("list is empty..!");
		}
		return res;
	}

	public Response addCustomer(Customer customer) {
		Customer prod = repo.save(customer);
		Response response = new Response();
		if (prod != null) {
			response.setStatus("Customer Added in DB Successfully...!");
			list2.add(prod);
			response.setCustomer(list2);
		} else {
			response.setStatus("Customer  Not Added in DB ...!");
			list2.add(customer);
			response.setCustomer(list2);
		}
		return response;
	}
	
	public Response updateCustomer(Customer customer) {
		Response response = new Response();
		Customer cust = repo.findById(customer.getAccount_no()).get();
		if (null != customer) {
			if (null != customer.getMobile_no()) {
				cust.setMobile_no(customer.getMobile_no());
			}
			if (null != customer.getUserName()) {
				cust.setUserName(customer.getUserName());
			}
			if (null != customer.getPassword()) {
				cust.setPassword(customer.getPassword());
			}
			repo.save(cust);
			list2.clear();
			list2.add(cust);
			response.setCustomer(list2);
		}
		return response;
	}
	
	
	public Response deleteCustomer(Customer customer) {
		Customer p = repo.findById(customer.getAccount_no()).get();
		Response response = new Response();
		if (p != null) {
			repo.delete(customer);
			response.setStatus("Data Deleted Successfully...!");
		} else {
			response.setStatus("Data Not Avilable in DB ...!");
		}
		return response;
	}


}
